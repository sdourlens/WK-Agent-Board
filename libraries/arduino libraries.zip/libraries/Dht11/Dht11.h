// FILE: dht11.h
// VERSION: 1
// PURPOSE: DHT11 Temperature & Humidity Sensor library for Arduino
// DATASHEET: http://www.micro4you.com/files/sensor/DHT11.pdf
//     URL: http://playground.arduino.cc/Main/DHT11Lib

#ifndef dht11_h
#define dht11_h

#include <arduino.h>

#define DHTLIB_OK				0
#define DHTLIB_ERROR_CHECKSUM	-1
#define DHTLIB_ERROR_TIMEOUT	-2

class dht11
{
private:
	char pin;
public:
    void init(char pin);
	char read();
	char humidity;
	char temperature;
};

#endif
